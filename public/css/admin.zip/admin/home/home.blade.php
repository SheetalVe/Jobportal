@extends('admin.layouts.default')
<style>
.no-padding{
    padding-left:0px;
    padding-right: 0px;
}
.gap-append{
    margin:10px 0px;
}
</style>
@section('content')
<h4>Welcome to Admin dashboard </h4>
@endsection



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Noogah</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!--Angular-->

  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/bootstrap/css/bootstrap.min.css")}}">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

   <!-- DataTables -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/datatables/dataTables.bootstrap.css")}}">

   <!-- Bower -->
  <link rel="stylesheet" href="{{asset("/components/select2/dist/css/select2.min.css")}}">

  <!-- Theme style -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/dist/css/AdminLTE.min.css")}}">
  <!-- AdminLTE Skins. Choose a skin from the css/skinsfolder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/dist/css/skins/_all-skins.min.css") }}">
  <!-- iCheck -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/iCheck/flat/blue.css") }}">
  <!-- Morris chart -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/morris/morris.css") }}">
  <!-- jvectormap -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/jvectormap/jquery-jvectormap-1.2.2.css") }}">
  <!-- Date Picker -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/datepicker/datepicker3.css") }}">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/daterangepicker/daterangepicker.css") }}">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css") }}">

  <!-- custom css -->
  <link rel="stylesheet" href="{{asset("/browser_components/adminlte/css/admin/custom.css")}}">
  <!-- <link rel="stylesheet" href="{{asset("/browser_components/adminlte/css/custom.css")}}"> -->
  
  <link href="{{asset("/browser_components/adminlte/calendar/jquery.datepick.css") }}" rel="stylesheet">

  <script src="{{asset("/components/jquery/dist/jquery.js")}}"></script>
<script src="{{asset("/components/select2/dist/js/select2.full.min.js")}}"></script>
  <script src="{{asset("/browser_components/adminlte/calendar/jquery.plugin.js") }}"></script>
  <script src="{{asset("/browser_components/adminlte/calendar/jquery.datepick.js") }}"></script>
  <!--map-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBfwQ5AzpnNXUE8cTzqw4zTInOlUDJyHRQ&libraries=places"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/geocomplete/1.7.0/jquery.geocomplete.min.js"></script>

  <!--set base url-->
  <script> 
    var baseUrl= "{{ url('/') }}/";
  </script>




</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="se-pre-con"></div>

<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>N</b>G</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Noo</b>Gah</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu"> <!--nab start here-->
        <ul class="nav navbar-nav">
          <li>
            <a href="{{ url('admin/logout') }}">Logout <i class="fa fa-sign-out" aria-hidden="true"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
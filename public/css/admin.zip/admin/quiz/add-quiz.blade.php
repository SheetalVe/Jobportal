@extends('admin.layouts.default')

@section('content')
    <div class = "error-msg">
        @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
        @endif
        @if(count($errors))
            <div class="alert alert-danger">
                @foreach($errors->all() as $error) 
                    <p>{{ $error }}  </p>
                    @break;
                @endforeach 
            </div>
        @endif 
    </div>

{!! Form::open(['url' => url('/admin/add-quiz'), 'files' => true]) !!}
    
    <div class="col-md-6 form-group"> 
    <label for="country">Quiz Type</label>
    {{ Form::select('quiz_type_id', $quizTypeArr, null, ['class' => 'form-control','placeholder' => 'Select Type']) }}
    </div>  

    <div class="col-md-6 form-group"> 
    <label for="country">Title</label>
    {{ Form::text('title', '', ['class'=>'form-control', 'placeholder'=>'Title']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Success Message</label>
    {{ Form::text('successful_message', '', ['class'=>'form-control', 'placeholder'=>'Success Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Unsuccess Message</label>
    {{ Form::text('unsuccessful_message', '', ['class'=>'form-control', 'placeholder'=>'Unsuccess Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Welcome Message</label>
    {{ Form::text('welcome_msg', '', ['class'=>'form-control', 'placeholder'=>'Welcome Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Start Date</label>
    {{ Form::date('start_date', '', ['class'=>'form-control', 'placeholder'=>'Start Date']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Close Date</label>
    {{ Form::date('close_date', '', ['class'=>'form-control', 'placeholder'=>'Close Date']) }}
    </div>

    <?php $answer_order_type = array('S'=>'S', 'R'=>'R'); ?>
    <div class="col-md-6 form-group">
    <label for="country">Answer Order Type</label>
    {{ Form::select('answer_order_type', $answer_order_type, null, ['class'=>'form-control', 'placeholder'=>'Select order']) }}
    </div>

    <?php $answer_option_listing = array('V'=>'V', 'H'=>'H'); ?>
    <div class="col-md-6 form-group">
    <label for="country">Answer Listing</label>
    {{ Form::select('answer_option_listing', $answer_option_listing, null, ['class'=>'form-control', 'placeholder'=>'Select list']) }}
    </div>

    <div class="col-md-6  form-group"> 
    <label for="country">Description</label>
    {{ Form::textarea('description', '', ['class'=>'form-control', 'placeholder'=>'Description..', 'rows' => 1, 'cols' => 100]) }}
    </div>

    <div class="col-md-6 form-group"> 
    <label for="country">Quiz Image</label>
        {{ Form::file('image', ['class'=>'form-control']) }}
    </div>


    <div class="col-md-12 form-group"> 
    {{ Form::submit($btnName, ['class'=>'btn btn-primary']) }}
    </div>

{!! Form::close() !!}


@endsection
@extends('admin.layouts.default')

@section('content') 
    @if(isset($_GET['redirect']))
        @if(session()->has('errorMsg'))
            <div class="alert alert-success error-message alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong> Success! </strong>  {{ Session::get('errorMsg') }}
            </div>
        @endif
    @endif
    <a href = "add-quiz-view" class="btn btn-primary add-type-button">{{ $btnName }}</a>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Title</th>
                <th>Answer Type</th>
                <th>Start Date</th>
                <th>Close Date</th>
                <th>Answer List</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($quizArr as $quiz)
            <tr>
                <td> {{ $quiz['title'] }} </td>
                <td> {{ $quiz['answer_order_type'] }} </td>
                <td> {{ $quiz['start_date'] }} </td>
                <td> {{ $quiz['close_date'] }} </td>
                <td> {{ $quiz['answer_option_listing'] }} </td>
                <td> <a href = "{{ route('editquiz', [ $quiz['quiz_id'] ]) }}" class="btn btn-primary edit-quiz-button">Edit</a> </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
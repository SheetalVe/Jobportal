@extends('admin.layouts.default')

@section('content')
    <div class = "error-msg">
        @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
        @endif
        @if(count($errors))
            <div class="alert alert-danger">
                @foreach($errors->all() as $error) 
                    <p>{{ $error }}  </p>
                    @break;
                @endforeach 
            </div>
        @endif 
    </div>

{!! Form::open(['url' => url('/admin/add-quiz'), 'files' => true]) !!}
    
    {{ Form::hidden('quiz_id', $quizArr['quiz_id'] , ['class'=>'form-control', 'placeholder'=>'Title']) }}

    <div class="col-md-6 form-group"> 
    <label for="country">Quiz Type</label>
    {{ Form::select('quiz_type_id', $quizTypeArr, $quizArr['quiz_type_id'], ['class' => 'form-control','placeholder' => 'Select Type']) }}
    </div>  

    <div class="col-md-6 form-group"> 
    <label for="country">Title</label>
    {{ Form::text('title', $quizArr['title'], ['class'=>'form-control', 'placeholder'=>'Title']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Success Message</label>
    {{ Form::text('successful_message', $quizArr['successful_message'], ['class'=>'form-control', 'placeholder'=>'Success Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Unsuccess Message</label>
    {{ Form::text('unsuccessful_message', $quizArr['unsuccessful_message'], ['class'=>'form-control', 'placeholder'=>'Unsuccess Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Welcome Message</label>
    {{ Form::text('welcome_msg', $quizArr['welcome_msg'], ['class'=>'form-control', 'placeholder'=>'Welcome Message']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Start Date</label>
    {{ Form::date('start_date', $quizArr['start_date'], ['class'=>'form-control', 'placeholder'=>'Start Date']) }}
    </div>

    <div class="col-md-6 form-group">
    <label for="country">Close Date</label>
    {{ Form::date('close_date', $quizArr['close_date'], ['class'=>'form-control', 'placeholder'=>'Close Date']) }}
    </div>

    <?php $answer_order_type = array('S'=>'S', 'R'=>'R'); ?>
    <div class="col-md-6 form-group">
    <label for="country">Answer Order Type</label>
    {{ Form::select('answer_order_type', $answer_order_type, $quizArr['answer_order_type'], ['class'=>'form-control', 'placeholder'=>'Select order']) }}
    </div>

    <?php $answer_option_listing = array('V'=>'V', 'H'=>'H'); ?>
    <div class="col-md-6 form-group">
    <label for="country">Answer Listing</label>
    {{ Form::select('answer_option_listing', $answer_option_listing, $quizArr['answer_option_listing'], ['class'=>'form-control', 'placeholder'=>'Select list']) }}
    </div>

    <div class="col-md-6  form-group"> 
    <label for="country">Description</label>
    {{ Form::textarea('description', $quizArr['description'], ['class'=>'form-control', 'placeholder'=>'Description..', 'rows' => 1, 'cols' => 100]) }}
    </div>

    <div class="col-md-6 form-group"> 
    <label for="country">Quiz Image</label>
        {{ Form::file('image', ['class'=>'form-control']) }}
        <div class="form-group"> 
            <img src = "{{$quizArr['image'] }}" >
        </div>
    </div>
    <div class="col-md-12 form-group"> 
    {{ Form::submit($btnName, ['class'=>'btn btn-primary']) }}
    </div>

{!! Form::close() !!}


@endsection
@extends('admin.layouts.default')

@section('content')
    @if(isset($_GET['redirect']))
        @if(session()->has('errorMsg'))
            <div class="alert alert-success error-message alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong> Success! </strong>  {{ Session::get('errorMsg') }}
            </div>
        @endif
    @endif
    <a href = "add-quiz-type-view" class="btn btn-primary add-type-button">{{ $btnName }}</a>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Title</th>
                <th>Name</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($quizTypeArr as $quizType)
            <tr>
                <td> {{ $quizType['title'] }} </td>
                <td> {{ $quizType['name'] }} </td>
                <td> {{ $quizType['created_at'] }} </td>
                <td> <a href = "{{ route('editquiztype', [ $quizType['id'] ]) }}" class="btn btn-primary edit-quiz-button">Edit</a> </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
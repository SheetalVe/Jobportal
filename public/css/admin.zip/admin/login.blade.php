<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="{{ asset("/browser_components/adminlte/bootstrap/css/bootstrap.min.css") }}">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
 
  <!-- Theme style -->
  <link rel="stylesheet" href="{{ asset("/browser_components/adminlte/dist/css/AdminLTE.min.css") }}">
  <!-- iCheck -->
  <link rel="stylesheet" href="{{ asset("/browser_components/adminlte/plugins/iCheck/square/blue.css") }}">
</head>
<body>
<div class="login-box">
  <div class="row">
    <div class="form-group">
      @if (session('status'))
      <div class="alert alert-success">
          {{ session('status') }}
      </div>
      @endif
      @if (count($errors)) 
        <div class="alert alert-danger">
            @foreach($errors->all() as $error) 
                <p>{{ $error }}  </p>
                @break;
            @endforeach 
        </div>
      @endif 
    </div>
  </div>

  <!-- /.login-logo -->
  <div class="login-box-body">
    <a class=" col-md-12 text-center clearfix" href="#">
      <img src="{{asset('/img/logo.png') }}">
      
    </a>
    <div class="clearfix">
    <p class="login-box-msg text-center">Admin Login</p>
</div>
    <form action="{{ url('admin/authenticate') }}" method="post">
    {{ csrf_field() }}
      <div class="form-group has-feedback">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <input type="text" class="form-control" placeholder="Username" name = "username">
      </div>
      <div class="form-group has-feedback">

        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <input type="password" class="form-control" placeholder="Password" name="password">
      </div>
      <div class="row">
        <div class="col-xs-8"></div>
        <div class="col-xs-4">
          <button type="submit" name = "submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
      </div>
    </form>

  </div>

</div>

</body>
</html>
<style>

.login-box-body .form-control-feedback{
  /*color:#fff;*/
}
.has-feedback .form-control {
    padding-left: 42.5px;
}
.form-control-feedback {
    position: absolute;
    top: 0;
    background: lightgray;
    left: 0;
  }
body {
    background: url(../browser_components/promotional/images/bg.jpg) no-repeat center center fixed transparent;
    overflow: hidden;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover; 
}

.login-box-body img{/*
      margin: 0 auto;
    text-align: center;
    width: 100px;
    height: 100px;
    border-radius: 15px;*/
    margin-bottom:20px;
}
.login-box-body{
  border-radius:10px;
  padding: 30px 20px 30px 20px;
}
.login-box{
  width: 410px;
  margin: 0 auto;
  position: absolute;
  left: 50%;
  top: 40%;
  transform: translate(-50%,-50%);
}

/*.btn-primary,.btn-primary:hover, .btn-primary:active, .btn-primary.hover {
     color:#fff;
    background-color: #ea9e22!important;
    border-color: #ea9e22!important;*/
}
</style>
@extends('admin.layouts.default')

@section('content')
    
    @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
    @endif
    @if(count($errors))
        <div class="alert alert-danger">
            @foreach($errors->all() as $error) 
                <p>{{ $error }}  </p>
                @break;
            @endforeach 
        </div>
    @endif 

{!! Form::open(['url' => url('/admin/add-form'), 'files' => true, 'method' => 'get']) !!}

    <div class="col-md-8  form-group"> 
    <label for="country">Title</label>
        {{ Form::text('title', '', ['class'=>'form-control', 'placeholder'=>'Title']) }}
    </div>

    <div class="col-md-8 form-group"> 
    <label for="country">Name</label>
        {{ Form::text('name', '', ['class'=>'form-control', 'placeholder'=>'Name']) }}
    </div>

    <div class="col-md-8  form-group"> 
    <label for="country">Description</label>
    {{ Form::textarea('description', '', ['class'=>'form-control', 'placeholder'=>'Description..', 'rows' => 3, 'cols' => 100]) }}
    </div>

    <div class="col-md-8  form-group"> 
        {{ Form::submit($btnName, ['class'=>'btn btn-primary']) }}
    </div>

{!! Form::close() !!}


@endsection
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Createuser extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('users', function (Blueprint $table) 
        {
            $table->increments('id');
            $table->string('first_name');
            $table->integer('last_name');
            $table->string('contact_no');
            $table->string('email');
            $table->string('gender');
            $table->string('long');
            $table->text('address');
            $table->string('lat');
            $table->string('setting');
            $table->string('profilepic');
            $table->string('type_of_person');
            $table->string('user_type_int');
            $table->string('password');
            $table->string('remember_token');
            $table->timestamp('updated_at')->nullable();
            $table->timestamp('created_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
    }
}
